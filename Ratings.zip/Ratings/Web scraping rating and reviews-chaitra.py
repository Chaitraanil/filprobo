#!/usr/bin/env python
# coding: utf-8

# In[1]:


#importing all the required libraries
import selenium
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import requests
from bs4 import BeautifulSoup
import os
import pandas as pd
from selenium.common.exceptions import StaleElementReferenceException, NoSuchElementException,ElementNotInteractableException,InvalidArgumentException,InvalidCookieDomainException


# In[46]:


#connecting to the webdriver
driver = webdriver.Chrome(r"C:\Users\chaitra\Downloads\chromedriver_win32_1\chromedriver.exe")


# In[3]:


url='https://www.flipkart.com/hp-pavilion-gaming-ryzen-5-quad-core-3550h-8-gb-1-tb-hdd-windows-10-home-4-gb-graphics-nvidia-geforce-gtx-1650-15-ec0101ax-laptop/product-reviews/itma1af6bf593dc8?pid=COMFSFNVDXG74QXR&lid=LSTCOMFSFNVDXG74QXRY8FRH2&marketplace=FLIPKART'


# In[9]:


#opening the webpage through our driver
driver.get(url)


# In[33]:


#creating empty lists
Rating=[]
Full_review=[]


# ### scraping ratings and reviews of laptops

# In[11]:


URL=[]
for j in range(0,147):
    review_tags=driver.find_elements_by_xpath("//nav[@class='yFHi8N']")
    for i in review_tags:
        review_tags1=i.find_element_by_tag_name("a")
        URL.append(review_tags1.get_attribute('href'))
        
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
        time.sleep(3)


# In[12]:


URL


# In[13]:


len(URL)


# In[14]:


List_of_url = []
for i in URL:
    if i not in List_of_url:
        List_of_url.append(i)


# In[15]:


len(List_of_url)


# In[16]:


List_of_url


# In[80]:


#going to the first url through our driver
driver.get(List_of_url[0])


# In[82]:


#running a loop to extract all the required information from url
Ratings=[]
Full_review=[]
from tqdm import tqdm
for i in tqdm(List_of_url):
    driver.get(i)
    
    
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))


# In[83]:


Ratings


# In[84]:


Full_review


# In[85]:


len(Ratings)


# In[86]:


len(Full_review)


# In[87]:


url='https://www.flipkart.com/apple-macbook-air-core-i5-5th-gen-8-gb-128-gb-ssd-mac-os-sierra-mqd32hn-a/product-reviews/itm0602f520428ca?pid=COMEVCPQBXBDFJ8C&lid=LSTCOMEVCPQBXBDFJ8C4V6AHG&marketplace=FLIPKART'


# In[88]:


#opening the webpage through our driver
driver.get(url)


# In[89]:


for i in range(0,328): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
    driver.execute_script("arguments[0].click();", button)
    
    time.sleep(2)


# In[90]:


len(Ratings)


# In[91]:


len(Full_review)


# In[92]:


url='https://www.flipkart.com/asus-celeron-dual-core-4-gb-1-tb-hdd-windows-10-home-x543ma-gq1015t-laptop/product-reviews/itmf8811674edbeb?pid=COMFSKF9UQH8RKYF&lid=LSTCOMFSKF9UQH8RKYFK8UKIL&marketplace=FLIPKART'


# In[99]:


#opening the webpage through our driver
driver.get(url)


# In[100]:


for i in range(0,97): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[101]:


len(Ratings)


# In[102]:


len(Full_review)


# In[103]:


url='https://www.flipkart.com/lenovo-ideapad-s145-ryzen-3-dual-core-3200u-4-gb-1-tb-hdd-windows-10-home-s145-15api-thin-light-laptop/product-reviews/itm3028b196c8fe1?pid=COMFJM3T7ZF2Z86F&lid=LSTCOMFJM3T7ZF2Z86FUWBWK9&marketplace=FLIPKART'


# In[104]:


#opening the webpage through our driver
driver.get(url)


# In[105]:


for i in range(0,73): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[106]:


len(Ratings)


# In[107]:


len(Full_review)


# ### scraping ratings and reviews of mobile phones

# In[110]:


url='https://www.flipkart.com/redmi-9-power-electric-green-64-gb/product-reviews/itmca7d78e222ed7?pid=MOBFYZ7AVAXXB2TH&lid=LSTMOBFYZ7AVAXXB2THVSNL0U&marketplace=FLIPKART'


# In[111]:


driver.get(url)


# In[112]:


for i in range(0,367): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[113]:


len(Ratings)


# In[114]:


len(Full_review)


# In[115]:


url='https://www.flipkart.com/motorola-g30-dark-pearl-64-gb/product-reviews/itme5ae7fa01f345?pid=MOBFVXGZWDHJHQGZ&lid=LSTMOBFVXGZWDHJHQGZBI5YJU&marketplace=FLIPKART'


# In[116]:


driver.get(url)


# In[117]:


for i in range(0,157): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[118]:


len(Ratings)


# In[119]:


len(Full_review)


# In[120]:


url='https://www.flipkart.com/motorola-e7-plus-misty-blue-64-gb/product-reviews/itm9a59be77f1cd2?pid=MOBFTYWW8QWUYDZU&lid=LSTMOBFTYWW8QWUYDZUM6DQNI&marketplace=FLIPKART'


# In[121]:


driver.get(url)


# In[122]:


for i in range(0,373): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[123]:


len(Ratings)


# In[124]:


len(Full_review)


# ### scraping ratings and reviews of headphones

# In[125]:


url='https://www.flipkart.com/mivi-collar-classic-fast-charging-bluetooth-headset/product-reviews/itmd6a3a8e12473f?pid=ACCGFGJTGWRHZUAF&lid=LSTACCGFGJTGWRHZUAF3XZAXJ&marketplace=FLIPKART'


# In[126]:


driver.get(url)


# In[127]:


for i in range(0,216): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[128]:


len(Ratings)


# In[129]:


len(Full_review)


# In[130]:


url='https://www.flipkart.com/ubon-ub-770-wired-headset/product-reviews/itmc75e7cc4986df?pid=ACCFHCAPHTPCCXZR&lid=LSTACCFHCAPHTPCCXZRKLYRFC&marketplace=FLIPKART'


# In[131]:


driver.get(url)


# In[132]:


for i in range(0,234): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[133]:


len(Ratings)


# In[134]:


len(Full_review)


# ### scraping ratings and reviews of smart watches

# In[135]:


url='https://www.flipkart.com/alonzo-dz09-new-phone-smartwatch/product-reviews/itm44bd98f3bf1e7?pid=SMWF5BFJHTDYCYYD&lid=LSTSMWF5BFJHTDYCYYDJIL5XV&marketplace=FLIPKART'


# In[140]:


driver.get(url)


# In[141]:


for i in range(0,106): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[142]:


len(Ratings)


# In[143]:


len(Full_review)


# In[144]:


url='https://www.flipkart.com/life-like-v8-bluetooth-sim-tf-card-slot-smartwatch/product-reviews/itm8deac9de357e6?pid=SMWEQJPTGWKCBDUD&lid=LSTSMWEQJPTGWKCBDUDPTTYUT&marketplace=FLIPKART'


# In[145]:


driver.get(url)


# In[146]:


for i in range(0,51): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[147]:


len(Ratings)


# In[148]:


len(Full_review)


# In[149]:


url='https://www.flipkart.com/fitbit-versa-special-smartwatch/product-reviews/itme0fd47f890e7f?pid=SMWFDYBW3829GKEY&lid=LSTSMWFDYBW3829GKEY8DNWTD&marketplace=FLIPKART'


# In[150]:


driver.get(url)


# In[151]:


for i in range(0,39): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[152]:


len(Ratings)


# In[153]:


len(Full_review)


# ### scraping ratings and reviews of professional cameras

# In[154]:


url='https://www.flipkart.com/canon-eos-3000d-dslr-camera-1-body-18-55-mm-lens-battery-battery-charger-usb-cable/product-reviews/itmed1b57035d2fc?pid=CAMF3DHJURPEMNRN&lid=LSTCAMF3DHJURPEMNRNYD4BKP&marketplace=FLIPKART'


# In[155]:


driver.get(url)


# In[156]:


for i in range(0,330): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[157]:


len(Ratings)


# In[158]:


len(Full_review)


# In[159]:


url='https://www.flipkart.com/nikon-d5600-dslr-camera-body-dual-lens-af-p-dx-nikkor-18-55-mm-f-3-5-5-6g-vr-70-300-f-4-5-6-3g-ed/product-reviews/itm8bd75efa91403?pid=DLLEZVB8MDXDYTHG&lid=LSTDLLEZVB8MDXDYTHGP8CUFI&marketplace=FLIPKART'


# In[160]:


driver.get(url)


# In[161]:


for i in range(0,169): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[162]:


len(Ratings)


# In[163]:


len(Full_review)


# ### scraping ratings and reviews of printers

# In[164]:


url='https://www.flipkart.com/canon-pixma-mg2470-all-in-one-inkjet-printer/product-reviews/itmdqatqsyzyzffn?pid=PRNDQAR9KZEKSKRF&lid=LSTPRNDQAR9KZEKSKRFEMB7B0&marketplace=FLIPKART'


# In[165]:


driver.get(url)


# In[166]:


for i in range(0,610): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[167]:


len(Ratings)


# In[168]:


len(Full_review)


# In[169]:


url='https://www.flipkart.com/hp-deskjet-2331-multi-function-color-printer/product-reviews/itm5708dbe303a73?pid=PRNFTXAWZ9DZ2KHR&lid=LSTPRNFTXAWZ9DZ2KHRP7ZAXV&marketplace=FLIPKART'


# In[170]:


driver.get(url)


# In[171]:


for i in range(0,52): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[172]:


len(Ratings)


# In[173]:


len(Full_review)


# ### scraping ratings and reviews of monitors

# In[174]:


url='https://www.flipkart.com/dell-18-5-inch-hd-led-backlit-tn-panel-monitor-d1918h/product-reviews/itmewm8z6awyx9rr?pid=MONEWM8ZKY38PWVP&lid=LSTMONEWM8ZKY38PWVPIKWEMH&marketplace=FLIPKART'


# In[175]:


driver.get(url)


# In[176]:


for i in range(0,58): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[177]:


len(Ratings)


# In[178]:


len(Full_review)


# In[179]:


url='https://www.flipkart.com/hp-23-8-inch-full-hd-led-backlit-ips-panel-monitor-24es/product-reviews/itm5613f46e3d8db?pid=MONEQFE5PQNQHHZF&lid=LSTMONEQFE5PQNQHHZFESEDRU&marketplace=FLIPKART'


# In[180]:


driver.get(url)


# In[181]:


for i in range(0,39): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[182]:


len(Ratings)


# In[183]:


len(Full_review)


# ### scraping ratings and reviews of home theaters

# In[184]:


url='https://www.flipkart.com/intex-it-2616-bt-55-w-bluetooth-home-theatre/product-reviews/itm835ba2477ca67?pid=ACCFNMEYJNHSNCWN&lid=LSTACCFNMEYJNHSNCWNXWFCRW&marketplace=FLIPKART'


# In[185]:


driver.get(url)


# In[186]:


for i in range(0,216): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[187]:


len(Ratings)


# In[188]:


len(Full_review)


# In[189]:


url='https://www.flipkart.com/intex-2622-portable-bluetooth-home-theatre/product-reviews/itmd7aeef0b49f57?pid=ACCEPBDW89GY8ZYU&lid=LSTACCEPBDW89GY8ZYUZCVLEQ&marketplace=FLIPKART'


# In[190]:


driver.get(url)


# In[191]:


for i in range(0,134): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[192]:


len(Ratings)


# In[193]:


len(Full_review)


# ### scraping ratings and reviews of routers

# In[194]:


url='https://www.flipkart.com/mi-r4cm-300-mbps-router/product-reviews/itm4ed0ab10f43e5?pid=RTRFZ9XMNKDBSHCY&lid=LSTRTRFZ9XMNKDBSHCY2N0IPP&marketplace=FLIPKART'


# In[195]:


driver.get(url)


# In[196]:


for i in range(0,143): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[197]:


len(Ratings)


# In[198]:


len(Full_review)


# In[199]:


url='https://www.flipkart.com/tenda-n301-300-mbps-router/product-reviews/itmehkf7am7tpawg?pid=RTRDYEYZKF884XRZ&lid=LSTRTRDYEYZKF884XRZA1WPYP&marketplace=FLIPKART'


# In[200]:


driver.get(url)


# In[201]:


for i in range(0,162): 
    for j in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq' or @class='_3LWZlK _32lA32 _1BLPMq' or @class='_3LWZlK _1rdVr6 _1BLPMq']"):
        Ratings.append(j.text)
            
            
    for k in driver.find_elements_by_xpath("//div[@class='t-ZTKy']/div/div"):
        Full_review.append(k.text.replace('\n',' '))
    
    try:
        button=driver.find_element_by_xpath("//*[contains(text(), 'Next')]")
        driver.execute_script("arguments[0].click();", button)
    except NoSuchElementException:
        pass
    time.sleep(2)


# In[204]:


#printing lengths
print(len(Ratings),len(Full_review))


# In[205]:


#creating a dataframe
Reviews=pd.DataFrame({})
Reviews['Ratings']=Ratings
Reviews['Full_review']=Full_review


# In[206]:


Reviews


# In[207]:


#converting into csv format
Reviews.to_csv("Reviews.csv")


# In[208]:


#closing the driver
driver.close()


# In[ ]:




