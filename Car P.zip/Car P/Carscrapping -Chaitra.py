#!/usr/bin/env python
# coding: utf-8

# ### Car Price Scraping

# In[1]:


#importing libraries
from selenium import webdriver
import time
import pandas as pd
import numpy as np
import urllib
import os
import sys


# In[79]:


#initialize web driver
driver = webdriver.Chrome(executable_path = r"C:\Users\Chaitra\Downloads\chromedriver.exe")
url = "https://www.olx.in/cars_c84"
driver.get(url)
time.sleep(3)


# In[6]:


#initialize lists
urls = []
cities = []


# In[71]:


#looping through different locations for getting urls of cars
locations = ["Bengaluru", "Delhi", "Mumbai", "Chennai", "Hyderabad", "Kochi", "Kozhikode", "Kolkata",             "Coimbatore", "Goa", "jaipur", "Chandigarh"]
for lc in locations:
    time.sleep(5)
    location = driver.find_element_by_class_name("_2xvhw")
    location.clear()
    time.sleep(3)
    location.send_keys(lc)
    time.sleep(5)
    try:
        loc_click = driver.find_element_by_class_name("_1jtbH")
        loc_click.click()
        #load more data
        for i in range(7):
            time.sleep(5)
            driver.find_elements_by_class_name("rui-3evoE")[-1].click()
        
    except Exception as e:
        continue
    lis = driver.find_elements_by_class_name("EIR5N")
    for li in lis:
        urls.append(li.find_element_by_tag_name("a").get_attribute("href"))
        cities.append(lc)


# In[7]:


#creating a dataframe and saving it as csv in case of kernal restart or any dataloss
olx = pd.DataFrame({"city":cities, "url": urls})


# In[17]:


olx


# In[56]:


#initilize lists for the vehicle info
brands = []
models = []
varient = []
mf_years = []
dr_kms = []
fuel_types = []
no_owners = []
locations = []
transmissions = []
prices = []


# In[57]:


#looping through the each url to get car data
for i in range(len(olx["city"])):
    url = olx["url"][i]
    driver.get(url)
    time.sleep(5)
    try:
        det = driver.find_elements_by_class_name("_2vNpt")
        br = det[0].text
        mo = det[1].text
        var = det[2].text
        mf = det[3].text
        fu = det[4].text
        tn = det[5].text
        km = det[6].text
        ow = det[7].text
        price = driver.find_element_by_class_name("_2xKfz").text
        brands.append(br)
        models.append(mo)
        varient.append(var)
        mf_years.append(mf)
        fuel_types.append(fu)
        transmissions.append(tn)
        dr_kms.append(km)
        no_owners.append(ow)
        prices.append(price)
        locations.append(olx["city"][i])
    except Exception as e:
        continue
        


# In[60]:


#create a df and save as csv for future use(in case of loss)
olxdf = pd.DataFrame({"brand":brands,"model":models, "varient":varient,"mf_year":mf_years, "dr_kms":dr_kms,              "fuel_type":fuel_types,"no_of_owners":no_owners,"location":locations,               "transmission":transmissions,"price":prices})


# In[61]:


olxdf.to_csv("olxdf.csv")


# In[2]:


#initialize web driver
driver = webdriver.Chrome(executable_path = r"C:\Users\DEVASREE\Downloads\chromedriver.exe")
url = "https://www.cars24.com"
driver.get(url)
time.sleep(3)


# In[21]:


#initialize lists
urls_24 = []
locs = []


# In[22]:


#looping through different locations for getting urls of cars
locations = ["bengaluru", "chennai", "new-delhi", "mumbai", "pune", "hyderabad", "kolkata", "ahmedabad",             "jaipur", "chandigarh"]
for lc in locations:
    url = "https://www.cars24.com/buy-used-cars-" + lc
    driver.get(url)
    time.sleep(5)
    for i in range(14):
        driver.execute_script("window.scrollTo(0, (document.body.scrollHeight)*.9);")
        time.sleep(5)
    divs = driver.find_elements_by_class_name("_9Ue0B")
    for div in divs:
        urls_24.append(div.get_attribute("href"))
        locs.append(lc)


# In[25]:


c24 = pd.DataFrame({"city":locs, "url": urls_24})


# In[218]:


brands = []
models = []
varient = []
mf_years = []
dr_kms = []
fuel_types = []
no_owners = []
locations = []
transmissions = []
prices = []


# In[219]:


c24 = pd.read_csv("c24.csv")


# In[220]:


#looping through the each url to get car data
for i in range(len(c24["city"])):
    url = c24["url"][i]
    driver.get(url)
    time.sleep(5)
    try:
        price = driver.find_elements_by_class_name("_2yYvS")[0].text
        title = driver.find_element_by_class_name("_2geSF").text.split()
        br = title[1]
        mo = title[2]
        var = " ".join(driver.find_element_by_class_name("_18vo2").text.split()[0:-1])
        mf = title[0]
        elem = driver.find_elements_by_class_name("_1-PH2")
        fu = elem[3].text
        tn = elem[5].text
        km = elem[2].text
        ow = elem[1].text
        brands.append(br)
        models.append(mo)
        varient.append(var)
        mf_years.append(mf)
        fuel_types.append(fu)
        transmissions.append(tn)
        dr_kms.append(km)
        no_owners.append(ow)
        prices.append(price)
        locations.append(c24["city"][i])
    except Exception as e:
        continue
        


# In[221]:


#create a df and save as csv for future use(in case of loss)
c24df = pd.DataFrame({"brand":brands,"model":models, "varient":varient,"mf_year":mf_years, "dr_kms":dr_kms,              "fuel_type":fuel_types,"no_of_owners":no_owners,"location":locations,               "transmission":transmissions,"price":prices})


# In[222]:


c24df


# In[223]:


c24df.to_csv("c24df1.csv")


# In[123]:


urls = []
cities = []


# In[124]:


#getting urls from cardekho
locations = ["kozhikode", "bengaluru", "ahmedabad", "chennai", "delhi-ncr", "gurgaon", "hyderabad", "jaipur", "kolkata",             "mumbai", "new-delhi", "noida", "pune"]
for lc in locations:
    url = "https://www.cardekho.com/used-cars+in+" + lc
    driver.get(url)
    time.sleep(5)
    j=1
    for i in range(25):
        time.sleep(5)
        driver.execute_script("window.scrollTo(0, (document.body.scrollHeight)*.1*"+str(j)+");")
        if j == 9:
            j = 7
        j += 1
        time.sleep(5)
    divs = driver.find_elements_by_class_name("carsName")
    for div in divs:
        urls.append(div.find_element_by_tag_name("a").get_attribute("href"))
        cities.append(lc)


# In[126]:


cdekho = pd.DataFrame({"city":cities, "url": urls})


# In[127]:


cdekho.to_csv("cdekho.csv")


# In[202]:


brands = []
models = []
varient = []
mf_years = []
dr_kms = []
fuel_types = []
no_owners = []
locations = []
transmissions = []
prices = []


# In[ ]:


#getting info from cardekho
for i in range(len(cdekho["city"])):
    url = cdekho["url"][i]
    time.sleep(5)
    try:
        price = driver.find_element_by_class_name("amount").text
        title = driver.find_element_by_class_name("vdp-head").find_elements_by_tag_name("h1")
        mf = title[0].text
        br = title[1].text.split()[0]
        mo = title[1].text.split()[1]
        var = " ".join(driver.find_element_by_class_name("vdp-head").text.split()[2:])
        elem = driver.find_elements_by_class_name("iconDetail")
        fu = elem[4].text
        tn = elem[5].text
        km = elem[2].text
        ow = elem[3].text
        
        brands.append(br)
        models.append(mo)
        varient.append(var)
        mf_years.append(mf)
        fuel_types.append(fu)
        transmissions.append(tn)
        dr_kms.append(km)
        no_owners.append(ow)
        prices.append(price)
        locations.append(cdekho["city"][i])
    except:
        try:
            price = driver.find_element_by_class_name("priceSection").text
            title = driver.find_element_by_xpath("//div[@class='variant-name']/preceding::h1").text.split()
            br = title[1]
            if len(title) == 3:
                mo = title[2]
            else:
                mo = ""
            var = driver.find_element_by_class_name("variant-name").text
            mf = title[0]
            det = driver.find_elements_by_class_name("overviewCArd")[0] 
            main = det.find_elements_by_class_name("fontweight500")
            fu = main[2].text
            tn = main[7].text
            km = main[3].text
            ow = main[5].text
            brands.append(br)
            models.append(mo)
            varient.append(var)
            mf_years.append(mf)
            fuel_types.append(fu)
            transmissions.append(tn)
            dr_kms.append(km)
            no_owners.append(ow)
            prices.append(price)
            locations.append(cdekho["city"][i])
        except Exception as e:
            continue
        


# In[204]:


cdekhodf = pd.DataFrame({"brand":brands,"model":models, "varient":varient,"mf_year":mf_years, "dr_kms":dr_kms,              "fuel_type":fuel_types,"no_of_owners":no_owners,"location":locations,               "transmission":transmissions,"price":prices})


# In[206]:


cdekhodf.to_csv("cdekhodf.csv")


# In[12]:


#concat data from three websites
data = pd.concat([olxdf, c24df, cdekhodf], axis=0)


# In[13]:



data


# In[14]:


data = data.iloc[: , 1:]


# In[16]:


#save as csv
data.to_csv("car_price.csv")


# In[ ]:




