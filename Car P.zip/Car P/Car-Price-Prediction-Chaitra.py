#!/usr/bin/env python
# coding: utf-8

# ### Car-Price-Prediction-ML
Car Price Prediction Project
With the covid 19 impact in the market, we have seen lot of changes in the car market. Now some cars are in demand hence making them costly and some are not in demand hence cheaper. One of our clients works with small traders, who sell used cars. With the change in market due to covid 19 impact, our client is facing problems with their previous car price valuation machine learning models. So, they are looking for new machine learning models from new data. We have to make car price valuation model. This project contains two phase-
Data Collection Phase –
You have to scrape at least 5000 used cars data. You can scrape more data as well, it’s up to you.
More the data better the model
In this section You need to scrape the data of used cars from websites (Olx, cardekho, Cars24 etc.)
You need web scraping for this. You have to fetch data for different locations. The number of
columns for data doesn’t have limit, it’s up to you and your creativity. Generally, these columns are Brand, model, variant, manufacturing year, driven kilometers, fuel, number of owners, location and at last target variable Price of the car. This data is to give you a hint about important variables in used car model. You can make changes to it, you can add or you can remove some columns, it completely depends on the website from which you are fetching the data.
Try to include all types of cars in your data for example- SUV, Sedans, Coupe, minivan, Hatchback. Note – The data which you are collecting is important to us. Kindly don’t share it on any public
platforms.
Model Building Phase-
After collecting the data, you need to build a machine learning model. Before model building do all data pre-processing steps. Try different models with different hyper parameters and select the best model.
Follow the complete life cycle of data science. Include all the steps like
1. Data Cleaning
2. Exploratory Data Analysis
3. Data Pre-processing
4. Model Building
5. Model Evaluation
6. Selecting the best model
# In[383]:


#importing required libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import re


# In[384]:


#read the data
data = pd.read_csv("car_price.csv")


# In[385]:


data = data.iloc[: , 1:]


# In[386]:


data


# In[387]:


#checking null values
data.isnull().sum()


# In[388]:


#droping the null rows
data = data.dropna()


# In[389]:


data


# In[390]:


data["brand"].unique()


# In[391]:


data[data["brand"] == "Land"]


# In[392]:


#changing the Rover model to range rover
data.loc[data["brand"] == "Land", "model"] = 'Range Rover'


# In[393]:


#From brand names, we understood that Maruti, land rover and mercedes is written in more
#than one format. so we are going to make each of them to single name
data.loc[data["brand"] == "Land", "brand"] = 'Land Rover'
data.loc[data["brand"] == "Landrover", "brand"] = 'Land Rover'
data.loc[data["brand"] == "Maruti Suzuki", "brand"] = 'Maruti'
data.loc[data["brand"] == "Mercedes-Benz", "brand"] = 'Mercedes'


# In[394]:


#remove "km" string and convert to integer for driven kilometers column
data["dr_kms"] = data["dr_kms"].apply(lambda x: int(re.sub('[,kms]', '', x.lower())))


# In[395]:


data["fuel_type"].unique()


# In[396]:


data["no_of_owners"].unique()


# In[397]:


#unifying the no of owner information
data.loc[data["no_of_owners"] == "1st", "no_of_owners"] = 'First Owner'
data.loc[data["no_of_owners"] == "2nd", "no_of_owners"] = 'Second Owner'
data.loc[data["no_of_owners"] == "3rd", "no_of_owners"] = 'Third Owner'
data.loc[data["no_of_owners"] == "4th Owner", "no_of_owners"] = 'Fourth Owner'
data.loc[data["no_of_owners"] == "2nd Owner", "no_of_owners"] = 'Second Owner'
data.loc[data["no_of_owners"] == "4+", "no_of_owners"] = 'Fourth & Above Owner'
data.loc[data["no_of_owners"] == "1st Owner", "no_of_owners"] = 'First Owner'
data.loc[data["no_of_owners"] == "3rd Owner", "no_of_owners"] = 'Third Owner'
data.loc[data["no_of_owners"] == "4th", "no_of_owners"] = 'Fourth Owner'


# In[398]:


data["no_of_owners"].unique()


# In[399]:


data["location"].unique()


# In[400]:


#unifying the location data
data.loc[data["location"] == "bengaluru", "location"] = 'Bengaluru'
data.loc[data["location"] == "new-delhi", "location"] = 'Delhi'
data.loc[data["location"] == "mumbai", "location"] = 'Mumbai'
data.loc[data["location"] == "chennai", "location"] = 'Chennai'
data.loc[data["location"] == "hyderabad", "location"] = 'Hyderabad'
data.loc[data["location"] == "delhi-ncr", "location"] = 'Delhi'
data.loc[data["location"] == "kozhikode", "location"] = 'Kozhikode'
data.loc[data["location"] == "kolkata", "location"] = 'Kolkata'
data.loc[data["location"] == "ahmedabad", "location"] = 'Ahmedabad'
data.loc[data["location"] == "jaipur", "location"] = 'Jaipur'
data.loc[data["location"] == "chandigarh", "location"] = 'Chandigarh'
data.loc[data["location"] == "gurgaon", "location"] = 'Gurgaon'
data.loc[data["location"] == "noida", "location"] = 'Noida'


# In[401]:


data["location"].unique()


# In[402]:


data["transmission"].value_counts()


# In[403]:


data.loc[data["transmission"] == "Manual", "transmission"] = 'MANUAL'
data.loc[data["transmission"] == "Automatic", "transmission"] = 'AUTOMATIC'


# In[404]:


data["transmission"].value_counts()


# In[405]:


#removing the wrongly scraped data from transmission column
data = data.loc[(data["transmission"] == "MANUAL") | (data["transmission"] == "AUTOMATIC")]


# In[406]:


data["transmission"].value_counts()


# In[407]:


#remove unwanted letters and charecters from price and convert into int


# In[408]:


data["price"] = data["price"].apply(lambda x: re.sub('[,₹*]', '', x.lower()))


# In[409]:


data["price"]


# In[410]:


data["price"] = data["price"].apply(lambda x: int(float(x.split()[0])*100000) if "lak" in x.lower() else int(x))


# In[411]:


data["price"]


# In[412]:


#EDA


# In[413]:


plt.figure(figsize=(30,20))
chart = sns.countplot(data.brand)
chart.tick_params(axis='x', rotation=90, labelsize = 25)


# In[414]:


#Most of the vehicles in used car industry are Maruti and Hyundai


# In[415]:


plt.figure(figsize=(30,20))
chart = sns.scatterplot(data.brand, data.price, s=155)
chart.tick_params(axis='x', rotation=90, labelsize = 25)
chart.tick_params(axis='y',  labelsize = 25)


# In[416]:


#Premium vehicles are very less
# The most expensive cars are  ferrari and lamborghini
#hyundai, datsun, and maruti are some of the budget friendly brands


# In[417]:


plt.figure(figsize=(30,20))
chart = sns.scatterplot(data.mf_year, data.price, s=155)
chart.tick_params(axis='x', rotation=90, labelsize = 25)
chart.tick_params(axis='y',  labelsize = 25)


# In[418]:


#lesser the age of the vehicle higher will be the price


# In[419]:


plt.figure(figsize=(30,20))
chart = sns.scatterplot(data.mf_year, data.dr_kms, s=155)
chart.tick_params(axis='x', rotation=90, labelsize = 25)
chart.tick_params(axis='y',  labelsize = 25)


# In[420]:


plt.figure(figsize=(30,20))
chart = sns.countplot(data.mf_year)
chart.tick_params(axis='x', rotation=90, labelsize = 25)
chart.tick_params(axis='y',  labelsize = 25)


# In[421]:


#we can wee that the purchasing of vehicles started booming around 2010
#from 2018, it has been started to decline


# In[422]:


plt.figure(figsize=(30,20))
plt.plot(data.dr_kms)


# In[423]:


plt.figure(figsize=(30,20))
sns.countplot(data.fuel_type)


# In[424]:


#most of the vehicles are petrol
#gas or hybrid vehicles are very less
#no electric vehicles in our dataset


# In[425]:


plt.figure(figsize=(30,20))
chart = sns.scatterplot(data.fuel_type, data.price, s=155)
chart.tick_params(axis='x', rotation=90, labelsize = 25)
chart.tick_params(axis='y',  labelsize = 25)


# In[426]:


#In used car industry, uncommon fueled vehicles are cheaper(CNG, LPG etc) than petrol and diesel


# In[427]:


plt.figure(figsize=(30,20))
chart = sns.scatterplot(data.no_of_owners, data.price, s=155)
chart.tick_params(axis='x', rotation=90, labelsize = 25)
chart.tick_params(axis='y',  labelsize = 25)


# In[428]:


#generally we can say that when no. of owners increases, price decreases


# In[429]:


plt.figure(figsize=(30,20))
sns.distplot(data.mf_year)


# In[430]:


#mf_year is right skewed


# In[431]:


plt.figure(figsize=(30,20))
sns.distplot(data.dr_kms)


# In[432]:


#dr_kms is left skwewd


# In[433]:


plt.figure(figsize=(30,20))
sns.boxplot(data.mf_year)


# In[434]:


plt.figure(figsize=(30,20))
sns.boxplot(data.dr_kms)


# In[435]:


#even though there are outliers as per the plot, decided to keep the data, because this is real values


# In[436]:


plt.figure(figsize=(30,20))
chart = sns.scatterplot(data.location, data.price, s=155)
chart.tick_params(axis='x', rotation=90, labelsize = 25)
chart.tick_params(axis='y',  labelsize = 25)


# In[437]:


#the prices of the car is not much differ from city to city


# In[438]:


plt.figure(figsize=(30,20))
chart = sns.scatterplot(data.transmission, data.price, s=155)
chart.tick_params(axis='x', rotation=90, labelsize = 25)
chart.tick_params(axis='y',  labelsize = 25)


# In[439]:


#automatic cars are more expensive


# In[440]:


plt.figure(figsize=(30,20))
chart = sns.countplot(data.fuel_type, hue=data.transmission)
chart.tick_params(axis='x', rotation=90, labelsize = 25)
chart.tick_params(axis='y',  labelsize = 25)


# In[441]:


#In every fuel type, manual is higher in number than automatic 


# In[442]:


#consider a particular brand for a closer observation
swift = data[(data.brand == "Maruti") & (data['model'] =="Swift")]


# In[443]:


swift


# In[444]:


plt.figure(figsize=(30,20))
chart = sns.scatterplot(swift.fuel_type, swift.price, s=155)
chart.tick_params(axis='x', rotation=90, labelsize = 25)
chart.tick_params(axis='y',  labelsize = 25)


# In[445]:


#petrol-diesel vaicles are almost in same price range, but others are cheaper


# In[446]:


plt.figure(figsize=(30,20))
chart = sns.scatterplot(swift.dr_kms, swift.price, s=155)
chart.tick_params(axis='x', rotation=90, labelsize = 25)
chart.tick_params(axis='y',  labelsize = 25)


# In[447]:


#When the driven kilometers are high, price is less


# In[448]:


plt.figure(figsize=(30,20))
chart = sns.scatterplot(swift.mf_year, swift.price, s=155)
chart.tick_params(axis='x', rotation=90, labelsize = 25)
chart.tick_params(axis='y',  labelsize = 25)


# In[449]:


#newer the vehicle, higher will be the price


# In[450]:


corr = data.corr()


# In[451]:


sns.heatmap(corr)


# In[452]:


#not much correlation is found between the variables
#driven kilometers and mf year are highly -ve correlated


# In[453]:


sns.pairplot(data)


# In[454]:


data.skew()


# In[455]:


#removing skewness


# In[ ]:


data["mf_year"] = np.sqrt(data["mf_year"])[0]
data["dr_kms"] = np.sqrt(data["dr_kms"])[0]


# In[459]:


#Encoding
from sklearn.preprocessing import LabelEncoder
cat_cols = ["brand", "model", "varient", "fuel_type", "no_of_owners", "location", "transmission"]
for col in cat_cols:
    data[col] = LabelEncoder().fit_transform(data[col])


# In[460]:


data


# In[462]:


x = data.iloc[:,:-1]


# In[464]:


y = data.iloc[:,-1]


# In[466]:


#scaling
from sklearn.preprocessing import MinMaxScaler


# In[468]:


scaler = MinMaxScaler()
x = scaler.fit_transform(x)


# In[470]:


from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score


# In[471]:


#finding best random state
max_acc = 0
max_rs = 0
for i in range(1,200):
    x_train, x_test, y_train, y_test = train_test_split(x,y,test_size = .22, random_state = i)
    lr = LinearRegression()
    lr.fit(x_train, y_train)
    pred = lr.predict(x_test)
    r2 = r2_score(y_test, pred)
    if r2 > max_acc:
        max_acc = r2
        max_rs = i
print("Best random state=",max_rs)


# In[472]:


x_train, x_test, y_train, y_test = train_test_split(x,y,test_size = .22, random_state = 44)


# In[473]:


models = {"SVR":SVR(),"KNN":KNeighborsRegressor(), "RandomForest":RandomForestRegressor(),"LinearRegression":LinearRegression(), "Ridge":Ridge(), "dtr":DecisionTreeRegressor() }
acc = {}
mod_list = []
for i in models:
    mod = i
    mod = models[i]
    #mod = DecisionTreeRegressor()
    mod.fit(x_train, y_train)
    pred = mod.predict(x_test)
    r2_sc = r2_score(y_test,pred)
    acc[i] = r2_sc
    mod_list.append(mod)
print(acc)


# In[474]:


#applying cross validation
from sklearn.model_selection import cross_val_score


# In[475]:


cv_list = {}
for i in mod_list:
    cv = cross_val_score(i, x, y, cv=7)
    cv_list[str(i)] = cv.mean()
print(cv_list)


# In[476]:


#Randomforest is the best model


# In[477]:



#hyperparameter tuning
from sklearn.model_selection import GridSearchCV


# In[478]:



param_grid = {  'bootstrap': [True], 'max_depth': [5, 10, None], 'max_features': ['auto', 'log2'], 'n_estimators': [5, 6, 7, 8, 9, 10, 11, 12, 13, 15]}


# In[479]:


GCV = GridSearchCV(RandomForestRegressor(),param_grid=param_grid, cv=7)


# In[480]:


GCV.fit(x_train, y_train)


# In[481]:


GCV.best_params_


# In[482]:


GCV_predict = GCV.best_estimator_.predict(x_test)


# In[483]:



r2_score(y_test, GCV_predict)


# In[484]:


#saving model
import joblib
joblib.dump(GCV.best_estimator_, "car_price.obj")


# In[ ]:




